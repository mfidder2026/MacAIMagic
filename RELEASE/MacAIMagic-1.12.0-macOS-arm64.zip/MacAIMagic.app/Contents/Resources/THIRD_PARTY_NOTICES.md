# Third-party notices

The release build of MacAIMagic bundles binaries built from llama.cpp (commit `ddf48f85c933c1f438212a02eb21e7b001d2d37d`, with `patches/0001-deepseek41-split-engram.patch` applied), under the following license:

```
MIT License

Copyright (c) 2023-2026 The ggml authors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

The models are not included. They are downloaded from Hugging Face from their publishers (see `tools/models.json`), under their own licenses: DeepSeek-V4.1-Flash-1017 and GLM-5.3-Flash are MIT-licensed, as are their quantized files; Qwen3.8-Flash-Next and its quantized files are under the Qwen license (see the model page on Hugging Face).

When it is built with `scripts/build_image_engine.sh`, the release build also bundles the image engine, built from
stable-diffusion.cpp (commit `58bb3c1b1cd4749e94e39f537e9adfce295dcaee`, MIT License, Copyright (c) 2023 leejet), which
includes ggml under the license above. Ministral-3-8B, FLUX.2 Klein 4B and the Qwen3-4B text model it uses are
Apache 2.0, from their publishers on Hugging Face.
