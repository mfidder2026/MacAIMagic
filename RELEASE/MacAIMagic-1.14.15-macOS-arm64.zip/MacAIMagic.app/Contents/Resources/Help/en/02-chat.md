---
title: Chatting
icon: bubble.left.and.bubble.right
keywords: conversation question think thinking temperature system prompt context summary go on image paste copy stop screenshot watch along error repeated stuck
---
## Asking a question
Type your question at the bottom and press **↩** or **⌘↩**. **⌥↩** starts a new line. The answer appears while the model writes; **Stop** ends it.

## Managing conversations
- **New conversation**: **New conversation** at the top of the conversations in the sidebar, the pencil at the top right, or ⌘N. There is no maximum; the list scrolls.
- **Delete**: move over a conversation and click the trash can, or select it and press Delete (also with a right-click). The app asks first. Stop a conversation that is busy first.

## Buttons below the input field
| Button | What it does |
|---|---|
| Image | Add an image (or drag it in, or paste it with ⌘V). Works when *vision* is on. |
| Think | Off, low, normal or high: how long the model thinks first (low 2,000 tokens, normal 8,000, high what Settings says). Works with every model that can think. Longer is better for hard questions, but slower. When the model works in steps, it thinks at most 4,000 tokens per step after the first. Choosing another level in the middle of a long conversation makes the model read that conversation once more: with DeepSeek the level stands at the top of the prompt. |
| Web | The model may search the web and read pages. |
| Work folder | Choose a folder the model may work in. |
| R W X | The rights in that folder: read, write, execute. |

## Context and summaries
A meter at the top of the conversation shows how much of the context it uses. At 80% the app first shortens long old tool output (files read, command output): the model gets its start and end, and the rest of the conversation stays word for word. If that is not enough, the model summarizes the start; the messages stay visible, with a line where the summary begins. You can also have it done right away.

## Watching along
When the model takes a screenshot on the way (of a program or the C64 emulator), a small copy shows with that step. After the answer they stay in a row under **Reasoning**; click one for a larger copy.

## When the model stops before it is done
Local models sometimes stop halfway. The app notices this, tells the model to go on, and shows that in the conversation. If it stops three times in a row, the app asks you to say "go on" or to give a hint.

## When the same error keeps coming back
When the model gets the same error three times in one answer (from a build or a script, for example), the app tells it: what it changed did not fix the error, so it should read the line the error names, word for word, and change only that line, instead of rewriting the whole file again. This happens again after every next three times. You see the note when you open that step. Line numbers do not count: an error that moved a few lines counts as the same one.

When the model writes the same file in full three times in one answer, and no command runs or builds it in between, the app says that too: build or run it now and fix only what goes wrong. A command counts when it names the file (for example `./build.sh intro.asm` or `build/intro.prg`).

## Answer settings
Under **Settings → Chat**: reasoning effort, how long the model may think (16,000 tokens by default), temperature (higher is more creative) and your own system prompt.

> Put general notes the model should know in every conversation in MACAIMAGIC.md: Settings → Chat → **Open file**.

Conversations are kept on this Mac. Delete one with a right-click in the sidebar.
