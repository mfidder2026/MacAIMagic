---
title: Privacy and security
icon: lock.shield
keywords: privacy security local cloud data password prompt injection
---
- **Everything local**: the model runs on this Mac. Your conversations, files and documents do not go to an AI service.
- **What does go to the internet**: search queries and web pages (only with **Web** on), model downloads, and what you share yourself with **Share on GitHub**.
- **Rights**: in a work folder, and for system management, you decide what the model may do without asking.
- **Passwords**: the app never asks for your password. When one is needed, macOS asks for it itself.
- **Prompt injection**: a web page or file can contain text that tries to steer the model. That is why you approve changes yourself, and why the app warns when a plan follows reading the web.
- **Connectors**: a connector on the internet sends what the model passes along to that service; one on this Mac does not. Tokens are in the Keychain.
- **Tasks**: a task or heartbeat works with the same rights as a conversation. A change always waits for your approval, also when you are not there.
- **Telegram**: your messages and the answers go through Telegram's servers, not end-to-end encrypted. Only paired accounts get an answer; the token is in the Keychain. The model and your files stay on the Mac.
- **Agent**: mail, the browser, apps and speech are off by default. Mail stays in the Mail app; the browser window has its own cookies; speech becomes text on this Mac. Sending, buying and deleting ask every time.
- **Network**: the API and cluster helpers listen only on this Mac or on the Thunderbolt cable by default.
